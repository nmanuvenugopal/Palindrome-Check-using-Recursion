word = input("Enter the word: ")

def palindrome_check(org_word):
    if len(org_word) == 0:
        return True
    if org_word[0] != org_word[len(org_word)-1]:
        return False
    # Every time when the recursive function runs it will push result to stack.
    # If the first and last element is same, we need to consider the first element again.
    # So, we have started from 1st index to the last
    return palindrome_check(org_word[1: -1])

print(palindrome_check(word))